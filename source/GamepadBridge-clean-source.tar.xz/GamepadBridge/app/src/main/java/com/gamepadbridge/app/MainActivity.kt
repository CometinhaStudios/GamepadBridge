package com.gamepadbridge.app

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.InputDevice
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gamepadbridge.app.data.GameProfile
import com.gamepadbridge.app.data.ProfileStore
import com.gamepadbridge.app.inject.ShizukuBridge
import com.gamepadbridge.app.service.GamepadBridgeService
import com.gamepadbridge.app.ui.MappingScreen
import com.gamepadbridge.app.ui.ControllerTestScreen
import com.gamepadbridge.app.input.ControllerTestState
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    @Volatile private var mappingScreenActive = false
    @Volatile private var mappingActive = false
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (mappingScreenActive && event.keyCode != KeyEvent.KEYCODE_BACK && event.device != null && !event.device.isVirtual) return true
        return super.dispatchKeyEvent(event)
    }
    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        return super.dispatchGenericMotionEvent(event)
    }
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshShizukuState()
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        shizukuAvailable = false
        shizukuPermission = false
    }
    private var shizukuAvailable by mutableStateOf(false)
    private var shizukuPermission by mutableStateOf(false)

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        refreshShizukuState()
        if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) ShizukuBridge.bind(this)
    }

    private fun refreshShizukuState() {
        val available = ShizukuBridge.isAvailable
        shizukuAvailable = available
        shizukuPermission = available && ShizukuBridge.hasPermission
        if (shizukuPermission) ShizukuBridge.bind(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        refreshShizukuState()

        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                val profileStore = remember { ProfileStore(applicationContext) }
                val profiles by profileStore.profilesFlow.collectAsState(initial = emptyList())
                val activeProfileId by profileStore.activeProfileIdFlow.collectAsState(initial = null)
                val coroutineScope = rememberCoroutineScope()
                LaunchedEffect(profiles, activeProfileId) {
                    if (activeProfileId == null) profiles.firstOrNull()?.let { profileStore.selectProfile(it.id) }
                }

                NavHost(navController, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            profiles = profiles,
                            activeProfileId = activeProfileId,
                            shizukuAvailable = shizukuAvailable,
                            shizukuPermission = shizukuPermission,
                            onRefreshShizuku = ::refreshShizukuState,
                            onRequestShizukuPermission = { ShizukuBridge.requestPermission() },
                            onSelectProfile = { id -> coroutineScope.launch { profileStore.selectProfile(id) } },
                            onCreateProfile = { name -> coroutineScope.launch { profileStore.createProfile(name) } },
                            onDeleteProfile = { id -> coroutineScope.launch { profileStore.deleteProfile(id) } },
                            onMap = {
                                val selectedId = activeProfileId ?: profiles.firstOrNull()?.id
                                if (selectedId != null) navController.navigate("mapping/$selectedId")
                            },
                            onToggleService = { starting ->
                                if (starting) GamepadBridgeService.start(this@MainActivity)
                                else GamepadBridgeService.stop(this@MainActivity)
                            },
                            onTest = { navController.navigate("test") }
                        )
                    }
                    composable("test") { ControllerTestScreen { navController.popBackStack() } }
                    composable("mapping/{profileId}") { entry ->
                        DisposableEffect(Unit) { mappingScreenActive = true; onDispose { mappingScreenActive = false } }
                        DisposableEffect(Unit) {
                            mappingActive = true
                            onDispose { mappingActive = false }
                        }
                        val profileId = entry.arguments?.getString("profileId").orEmpty()
                        val profileName = profiles.firstOrNull { it.id == profileId }?.name ?: "Perfil"
                        MappingScreen(
                            profileId = profileId,
                            profileName = profileName,
                            profileStore = profileStore
                        ) { navController.popBackStack() }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshShizukuState()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        super.onDestroy()
    }
}

@Composable
private fun HomeScreen(
    profiles: List<GameProfile>,
    activeProfileId: String?,
    shizukuAvailable: Boolean,
    shizukuPermission: Boolean,
    onRefreshShizuku: () -> Unit,
    onRequestShizukuPermission: () -> Unit,
    onSelectProfile: (String) -> Unit,
    onCreateProfile: (String) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onMap: () -> Unit,
    onToggleService: (Boolean) -> Unit,
    onTest: () -> Unit
) {
    var serviceRunning by remember { mutableStateOf(false) }
    var profileMenuExpanded by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }
    val activeProfile = profiles.firstOrNull { it.id == activeProfileId } ?: profiles.firstOrNull()
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Gamepad Bridge", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Perfis independentes por jogo, mapeamento de controle e teclado.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(14.dp))
        when {
            !shizukuAvailable -> Text("Shizuku indisponível. Você ainda pode gerenciar perfis; conecte o Shizuku para mapear e iniciar a ponte.")
            !shizukuPermission -> Text("Shizuku conectado, mas o Gamepad Bridge ainda precisa de autorização.")
            else -> Text("Shizuku conectado e autorizado.", color = MaterialTheme.colorScheme.primary)
        }
        if (!shizukuAvailable) {
            OutlinedButton(onClick = onRefreshShizuku, modifier = Modifier.fillMaxWidth()) { Text("Verificar Shizuku novamente") }
        } else if (!shizukuPermission) {
            Button(onClick = onRequestShizukuPermission, modifier = Modifier.fillMaxWidth()) { Text("Conceder acesso ao Shizuku") }
            TextButton(onClick = onRefreshShizuku) { Text("Verificar permissão") }
        } else {
            TextButton(onClick = onRefreshShizuku) { Text("Atualizar conexão") }
        }
        Spacer(Modifier.height(12.dp))
        Text("Perfis por jogo", style = MaterialTheme.typography.titleMedium)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { profileMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), enabled = profiles.isNotEmpty()) {
                Text(activeProfile?.name ?: "Nenhum perfil criado")
            }
            DropdownMenu(expanded = profileMenuExpanded, onDismissRequest = { profileMenuExpanded = false }) {
                profiles.forEach { profile ->
                    DropdownMenuItem(text = { Text(profile.name) }, onClick = {
                        profileMenuExpanded = false
                        if (serviceRunning) { serviceRunning = false; onToggleService(false) }
                        onSelectProfile(profile.id)
                    }, trailingIcon = { if (profile.id == activeProfile?.id) Text("Ativo") })
                }
            }
        }
        OutlinedButton(onClick = { showCreateDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Criar perfil") }
        if (activeProfile != null) {
            Spacer(Modifier.height(8.dp))
            Text(activeProfile.controller?.let { "Dispositivo: ${it.deviceLabel}" } ?: "Este perfil ainda não tem mapeamento.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = {
                if (serviceRunning) { serviceRunning = false; onToggleService(false) }
                onMap()
            }, enabled = shizukuPermission, modifier = Modifier.fillMaxWidth()) {
                Text(if (activeProfile.controller == null) "Mapear controle / teclado" else "Editar mapeamento")
            }
            Button(onClick = {
                serviceRunning = !serviceRunning
                onToggleService(serviceRunning)
            }, enabled = shizukuPermission && activeProfile.controller?.mapping?.isNotEmpty() == true, modifier = Modifier.fillMaxWidth()) {
                Text(if (serviceRunning) "Parar ponte" else "Iniciar ponte")
            }
            if (profiles.size > 1) TextButton(onClick = {
                if (serviceRunning) { serviceRunning = false; onToggleService(false) }
                onDeleteProfile(activeProfile.id)
            }) { Text("Excluir perfil ativo") }
        }
        OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth()) { Text("Testar controle") }
    }
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Criar perfil") },
            text = { Column {
                Text("Use um nome que identifique o jogo, por exemplo Minecraft ou GTA.")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = newProfileName, onValueChange = { newProfileName = it }, label = { Text("Nome do perfil") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                val name = newProfileName.trim()
                if (name.isNotEmpty()) { if (serviceRunning) { serviceRunning = false; onToggleService(false) }; onCreateProfile(name) }
                newProfileName = ""; showCreateDialog = false
            }, enabled = newProfileName.isNotBlank()) { Text("Criar") } },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancelar") } }
        )
    }
}

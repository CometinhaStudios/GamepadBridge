package com.gamepadbridge.app.ui

import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.gamepadbridge.app.data.ControllerProfile
import com.gamepadbridge.app.data.ProfileStore
import com.gamepadbridge.app.data.RawSource
import com.gamepadbridge.app.data.XboxInput
import com.gamepadbridge.app.input.CalibrationCapture
import com.gamepadbridge.app.input.DeviceNodeReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

@Composable
fun MappingScreen(
    profileId: String,
    profileName: String,
    profileStore: ProfileStore,
    onDone: () -> Unit
) {
    val context = LocalContext.current
    var lastBackAt by remember { mutableLongStateOf(0L) }
    BackHandler {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBackAt < 900L) onDone() else {
            lastBackAt = now
            Toast.makeText(context, "Aperte Voltar novamente para sair do mapeamento", Toast.LENGTH_SHORT).show()
        }
    }
    var devices by remember { mutableStateOf<List<DeviceNodeReader.DeviceEntry>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    var selectedDevice by remember { mutableStateOf<DeviceNodeReader.DeviceEntry?>(null) }
    var lastBackPress by remember { mutableLongStateOf(0L) }

    val scope = rememberCoroutineScope()
    fun refreshDevices() {
        scope.launch {
            scanning = true
            devices = withContext(Dispatchers.IO) { DeviceNodeReader.listDevices() }
            scanning = false
        }
    }

    LaunchedEffect(Unit) { refreshDevices() }

    if (selectedDevice == null) {
        DeviceSelectStep(
            profileName = profileName,
            devices = devices,
            scanning = scanning,
            onRefresh = ::refreshDevices,
            onSelected = { selectedDevice = it },
            onBack = onDone
        )
    } else {
        CalibrationStep(
            device = selectedDevice!!,
            profileId = profileId,
            profileStore = profileStore,
            onBack = { selectedDevice = null },
            onDone = onDone
        )
    }
}

@Composable
private fun DeviceSelectStep(
    profileName: String,
    devices: List<DeviceNodeReader.DeviceEntry>,
    scanning: Boolean,
    onRefresh: () -> Unit,
    onSelected: (DeviceNodeReader.DeviceEntry) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Mapear: $profileName", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(
            "Conecte o controle USB/Bluetooth ou teclado. Se ele não aparecer, atualize a lista com o Shizuku autorizado.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack) { Text("Voltar") }
            Button(onClick = onRefresh, enabled = !scanning) {
                Text(if (scanning) "Buscando..." else "Atualizar dispositivos")
            }
        }
        Spacer(Modifier.height(12.dp))
        if (devices.isEmpty()) {
            Text("Nenhum controle ou teclado compatível foi listado.", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Text(
                "Confira se o Shizuku está ativo e autorizado. Conecte o dispositivo antes de tocar em Atualizar dispositivos.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        LazyColumn(Modifier.weight(1f)) {
            items(devices, key = { it.node }) { device ->
                ListItem(
                    headlineContent = { Text(device.name) },
                    supportingContent = { Text("${device.kind} • ${device.node}") },
                    trailingContent = { Button(onClick = { onSelected(device) }) { Text("Usar") } },
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun CalibrationStep(
    device: DeviceNodeReader.DeviceEntry,
    profileId: String,
    profileStore: ProfileStore,
    onBack: () -> Unit,
    onDone: () -> Unit
) {
    val order = XboxInput.mappingOrder
    var index by remember { mutableIntStateOf(0) }
    val collected = remember { mutableStateMapOf<XboxInput, RawSource>() }
    var candidate by remember { mutableStateOf<RawSource?>(null) }
    val scope = rememberCoroutineScope()

    DisposableEffect(device.node) {
        CalibrationCapture.start(device.node)
        onDispose { CalibrationCapture.stop(device.node) }
    }

    LaunchedEffect(index, candidate) {
        val target = order.getOrNull(index) ?: return@LaunchedEffect
        if (candidate != null) return@LaunchedEffect
        candidate = CalibrationCapture.events.first { source ->
            collected.values.none { it.identity() == source.identity() }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            
        }
        Text("Mapeamento de entradas", style = MaterialTheme.typography.headlineSmall)
        Text(device.name, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))

        if (index < order.size) {
            val current = order[index]
            Text("Pressione ou mova: ${current.label}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text("${index + 1} de ${order.size}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            XboxControllerVisual(highlight = current, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            candidate?.let { detected ->
                Text("Detectado: ${detected.serialize()}", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        collected[current] = detected
                        candidate = null
                        index = (index + 1).coerceAtMost(order.size)
                    }) { Text("Confirmar") }
                    OutlinedButton(onClick = { candidate = null }) { Text("Tentar novamente") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    candidate = null
                    if (index > 0) collected.remove(order[index - 1])
                    index = (index - 1).coerceAtLeast(0)
                }, enabled = index > 0) { Text("Anterior") }
                OutlinedButton(onClick = {
                    candidate = null
                    index = (index + 1).coerceAtMost(order.size)
                }) { Text("Pular") }
                OutlinedButton(onClick = { collected.remove(current); candidate = null }) {
                    Text("Limpar entrada")
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (current.isAxis) "Mova o analógico ou gatilho até o fim em uma direção. Para teclado, pule os eixos." 
                else "Pressione uma tecla do teclado ou botão do controle.",
                style = MaterialTheme.typography.bodySmall
            )
            if (collected.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("Entradas reconhecidas", style = MaterialTheme.typography.titleSmall)
                collected.entries.toList().takeLast(5).forEach { (target, source) ->
                    Text("${target.label}: ${source.serialize()}", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            Text("Mapeamento concluído", style = MaterialTheme.typography.titleLarge)
            Text("${collected.size} de ${order.size} entradas configuradas.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                scope.launch {
                    profileStore.saveControllerProfile(
                        profileId,
                        ControllerProfile(device.node, collected.toMap(), device.name)
                    )
                    onDone()
                }
            }) { Text("Salvar neste perfil") }
        }
    }
}

private fun RawSource.identity(): String = when (this) {
    is RawSource.Key -> "KEY:$code"
    is RawSource.Axis -> "AXIS:$code:${if (positiveDirection) "+" else "-"}"
}

package com.gamepadbridge.app.inject

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku
import rikka.shizuku.Shizuku.UserServiceArgs

object ShizukuBridge {
    private const val REQUEST_CODE = 9001
    @Volatile private var injector: IGamepadInjector? = null
    @Volatile private var binding = false

    val isAvailable: Boolean get() = Shizuku.pingBinder()
    val hasPermission: Boolean get() = isAvailable && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun requestPermission() {
        if (isAvailable && !hasPermission) Shizuku.requestPermission(REQUEST_CODE)
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            injector = IGamepadInjector.Stub.asInterface(binder)
            binding = false
            binder.linkToDeath({ injector = null; binding = false }, 0)
        }
        override fun onServiceDisconnected(name: ComponentName) { injector = null; binding = false }
    }

    @Synchronized fun bind(context: Context) {
        if (!hasPermission || injector != null || binding) return
        binding = true
        val args = UserServiceArgs(
            ComponentName(context.packageName, GamepadInjectorUserService::class.java.name)
        ).daemon(false).processNameSuffix("injector").debuggable(false).version(1)
        runCatching { Shizuku.bindUserService(args, connection) }
            .onFailure { binding = false }
    }

    fun injectKey(keyCode: Int, down: Boolean, source: Int) {
        runCatching { injector?.injectKey(keyCode, down, source) }
    }

    fun injectAxisBatch(axes: IntArray, values: FloatArray, source: Int) {
        runCatching { injector?.injectAxisBatch(axes, values, source) }
    }
}

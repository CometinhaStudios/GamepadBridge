package com.gamepadbridge.app.input

import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import android.view.KeyEvent
import android.view.MotionEvent
import com.gamepadbridge.app.data.XboxInput

object ControllerTestState {
    val pressed = mutableStateMapOf<Int, Boolean>()
    val axes = mutableStateOf(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f))
    @Volatile var enabled: Boolean = false

    fun key(code: Int, down: Boolean) { pressed[code] = down }
    fun axes(lx: Float, ly: Float, rx: Float, ry: Float, lt: Float, rt: Float) {
        axes.value = floatArrayOf(lx, ly, rx, ry, lt, rt)
    }
    fun clear() { pressed.clear(); axes.value = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f) }
    fun highlight(): XboxInput? {
        val key = pressed.entries.lastOrNull { it.value }?.key ?: return null
        return when (key) {
            KeyEvent.KEYCODE_BUTTON_A -> XboxInput.A
            KeyEvent.KEYCODE_BUTTON_B -> XboxInput.B
            KeyEvent.KEYCODE_BUTTON_X -> XboxInput.X
            KeyEvent.KEYCODE_BUTTON_Y -> XboxInput.Y
            KeyEvent.KEYCODE_BUTTON_L1 -> XboxInput.L1
            KeyEvent.KEYCODE_BUTTON_R1 -> XboxInput.R1
            KeyEvent.KEYCODE_BUTTON_THUMBL -> XboxInput.L3
            KeyEvent.KEYCODE_BUTTON_THUMBR -> XboxInput.R3
            KeyEvent.KEYCODE_BUTTON_START -> XboxInput.START
            KeyEvent.KEYCODE_BUTTON_SELECT -> XboxInput.BACK
            KeyEvent.KEYCODE_DPAD_UP -> XboxInput.DPAD_UP
            KeyEvent.KEYCODE_DPAD_DOWN -> XboxInput.DPAD_DOWN
            KeyEvent.KEYCODE_DPAD_LEFT -> XboxInput.DPAD_LEFT
            KeyEvent.KEYCODE_DPAD_RIGHT -> XboxInput.DPAD_RIGHT
            else -> null
        }
    }
}

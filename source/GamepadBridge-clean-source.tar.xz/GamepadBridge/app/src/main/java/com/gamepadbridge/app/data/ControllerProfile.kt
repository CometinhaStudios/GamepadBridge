package com.gamepadbridge.app.data

import android.view.KeyEvent
import android.view.MotionEvent

/** Xbox-like outputs that can be generated from a physical control or keyboard. */
enum class XboxInput(val label: String, val isAxis: Boolean = false) {
    A("A"), B("B"), X("X"), Y("Y"),
    L1("LB"), R1("RB"),
    L3("Clique do analógico esquerdo"), R3("Clique do analógico direito"),
    START("Start"), BACK("Select / Back"),
    DPAD_UP("D-Pad Cima"), DPAD_DOWN("D-Pad Baixo"), DPAD_LEFT("D-Pad Esquerda"), DPAD_RIGHT("D-Pad Direita"),
    L2("Gatilho Esquerdo (LT)", isAxis = true),
    R2("Gatilho Direito (RT)", isAxis = true),
    LS_X("Analógico Esquerdo — Eixo X (legado)", isAxis = true),
    LS_Y("Analógico Esquerdo — Eixo Y (legado)", isAxis = true),
    RS_X("Analógico Direito — Eixo X (legado)", isAxis = true),
    RS_Y("Analógico Direito — Eixo Y (legado)", isAxis = true),
    LS_LEFT("Analógico esquerdo — mover para ESQUERDA", isAxis = true),
    LS_RIGHT("Analógico esquerdo — mover para DIREITA", isAxis = true),
    LS_UP("Analógico esquerdo — mover para CIMA", isAxis = true),
    LS_DOWN("Analógico esquerdo — mover para BAIXO", isAxis = true),
    RS_LEFT("Analógico direito — mover para ESQUERDA", isAxis = true),
    RS_RIGHT("Analógico direito — mover para DIREITA", isAxis = true),
    RS_UP("Analógico direito — mover para CIMA", isAxis = true),
    RS_DOWN("Analógico direito — mover para BAIXO", isAxis = true);

    companion object {
        val mappingOrder = listOf(
            A, B, X, Y, L1, R1, L3, R3, START, BACK,
            DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT,
            L2, R2,
            LS_LEFT, LS_RIGHT, LS_UP, LS_DOWN,
            RS_LEFT, RS_RIGHT, RS_UP, RS_DOWN
        )
    }
}

/** Kernel input event captured from getevent. Keyboard keys and gamepad buttons
 * are both represented as Key; analog axes include the direction used while
 * calibrating so inverted pedals/axes can be mapped naturally. */
sealed class RawSource {
    data class Key(val code: String) : RawSource()
    data class Axis(val code: String, val positiveDirection: Boolean) : RawSource()

    fun serialize(): String = when (this) {
        is Key -> "KEY:$code"
        is Axis -> "AXIS:$code:${if (positiveDirection) "+" else "-"}"
    }

    companion object {
        fun deserialize(value: String): RawSource? {
            val parts = value.split(":")
            return when {
                parts.size == 2 && parts[0] == "KEY" -> Key(parts[1])
                parts.size == 3 && parts[0] == "AXIS" -> Axis(parts[1], parts[2] == "+")
                else -> null
            }
        }
    }
}

/** A mapping for one physical input node. deviceName keeps the event node path
 * so the background service can continue reading it when a game is in front. */
data class ControllerProfile(
    val deviceName: String,
    val mapping: Map<XboxInput, RawSource>,
    val deviceLabel: String = deviceName
) {
    fun serialize(): String = buildString {
        append(deviceName).append('\n')
        append(deviceLabel).append('\n')
        mapping.forEach { (input, source) -> append(input.name).append('=').append(source.serialize()).append('\n') }
    }

    companion object {
        fun deserialize(text: String): ControllerProfile? {
            val lines = text.lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) return null
            val node = lines[0]
            // Older versions had no label line, so detect the first mapping row.
            val labelLineIsMapping = lines.getOrNull(1)?.contains('=') == true
            val label = if (labelLineIsMapping) node else lines.getOrNull(1) ?: node
            val mappingLines = if (labelLineIsMapping) lines.drop(1) else lines.drop(2)
            val map = mutableMapOf<XboxInput, RawSource>()
            mappingLines.forEach { line ->
                val separator = line.indexOf('=')
                if (separator <= 0) return@forEach
                runCatching {
                    val input = XboxInput.valueOf(line.substring(0, separator))
                    val source = RawSource.deserialize(line.substring(separator + 1))
                    if (source != null) map[input] = source
                }
            }
            return ControllerProfile(node, map, label)
        }

        fun outputKeyCode(input: XboxInput): Int? = when (input) {
            XboxInput.A -> KeyEvent.KEYCODE_BUTTON_A
            XboxInput.B -> KeyEvent.KEYCODE_BUTTON_B
            XboxInput.X -> KeyEvent.KEYCODE_BUTTON_X
            XboxInput.Y -> KeyEvent.KEYCODE_BUTTON_Y
            XboxInput.L1 -> KeyEvent.KEYCODE_BUTTON_L1
            XboxInput.R1 -> KeyEvent.KEYCODE_BUTTON_R1
            XboxInput.L2 -> KeyEvent.KEYCODE_BUTTON_L2
            XboxInput.R2 -> KeyEvent.KEYCODE_BUTTON_R2
            XboxInput.L3 -> KeyEvent.KEYCODE_BUTTON_THUMBL
            XboxInput.R3 -> KeyEvent.KEYCODE_BUTTON_THUMBR
            XboxInput.START -> KeyEvent.KEYCODE_BUTTON_START
            XboxInput.BACK -> KeyEvent.KEYCODE_BUTTON_SELECT
            XboxInput.DPAD_UP -> KeyEvent.KEYCODE_DPAD_UP
            XboxInput.DPAD_DOWN -> KeyEvent.KEYCODE_DPAD_DOWN
            XboxInput.DPAD_LEFT -> KeyEvent.KEYCODE_DPAD_LEFT
            XboxInput.DPAD_RIGHT -> KeyEvent.KEYCODE_DPAD_RIGHT
            else -> null
        }

        fun outputAxis(input: XboxInput): Int? = when (input) {
            XboxInput.LS_X, XboxInput.LS_LEFT, XboxInput.LS_RIGHT -> MotionEvent.AXIS_X
            XboxInput.LS_Y, XboxInput.LS_UP, XboxInput.LS_DOWN -> MotionEvent.AXIS_Y
            XboxInput.RS_X, XboxInput.RS_LEFT, XboxInput.RS_RIGHT -> MotionEvent.AXIS_Z
            XboxInput.RS_Y, XboxInput.RS_UP, XboxInput.RS_DOWN -> MotionEvent.AXIS_RZ
            XboxInput.L2 -> MotionEvent.AXIS_LTRIGGER
            XboxInput.R2 -> MotionEvent.AXIS_RTRIGGER
            else -> null
        }
    }
}

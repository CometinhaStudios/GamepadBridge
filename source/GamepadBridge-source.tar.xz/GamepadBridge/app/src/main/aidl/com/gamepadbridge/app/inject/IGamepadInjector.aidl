package com.gamepadbridge.app.inject;

// Roda no processo do Shizuku (UID shell), que tem a permissão INJECT_EVENTS.
// É por aqui que injetamos eventos de "gamepad de verdade" no sistema, mesmo
// com outro app (o jogo) em primeiro plano.
interface IGamepadInjector {
    void injectKey(int keyCode, boolean down, int source);
    void injectAxisBatch(in int[] axes, in float[] values, int source);
    void destroy();
}

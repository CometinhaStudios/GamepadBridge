package com.gamepadbridge.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.gamepadbridge.app.data.XboxInput

/**
 * Desenho simplificado de um controle Xbox em formato "top-down", com o
 * elemento correspondente ao XboxInput atual destacado em outra cor. Serve
 * como referência visual pra quem tem um controle com legendas diferentes
 * (ex: "1,2,3,4" em vez de "A,B,X,Y").
 */
@Composable
fun XboxControllerVisual(highlight: XboxInput?, modifier: Modifier = Modifier) {
    val highlightColor = MaterialTheme.colorScheme.primary
    val baseColor = MaterialTheme.colorScheme.outline

    Canvas(modifier = modifier.fillMaxWidth().aspectRatio(1.6f)) {
        val w = size.width
        val h = size.height

        fun color(input: XboxInput) = if (input == highlight) highlightColor else baseColor

        // Corpo
        drawRoundRect(baseColor, cornerRadius = androidx.compose.ui.geometry.CornerRadius(40f, 40f),
            style = Stroke(3f))

        // Analógico esquerdo (também representa LS_X / LS_Y)
        val lsCenter = Offset(w * 0.26f, h * 0.55f)
        drawCircle(color(XboxInput.LS_X).takeIf { highlight == XboxInput.LS_X || highlight == XboxInput.LS_Y || highlight == XboxInput.L3 } ?: baseColor,
            radius = w * 0.09f, center = lsCenter, style = Stroke(4f))

        // Analógico direito
        val rsCenter = Offset(w * 0.62f, h * 0.68f)
        drawCircle(if (highlight == XboxInput.RS_X || highlight == XboxInput.RS_Y || highlight == XboxInput.R3) highlightColor else baseColor,
            radius = w * 0.09f, center = rsCenter, style = Stroke(4f))

        // D-Pad
        val dpadCenter = Offset(w * 0.26f, h * 0.25f)
        val dpadArm = w * 0.045f
        drawDpadArrow(dpadCenter, Offset(0f, -1f), dpadArm, color(XboxInput.DPAD_UP))
        drawDpadArrow(dpadCenter, Offset(0f, 1f), dpadArm, color(XboxInput.DPAD_DOWN))
        drawDpadArrow(dpadCenter, Offset(-1f, 0f), dpadArm, color(XboxInput.DPAD_LEFT))
        drawDpadArrow(dpadCenter, Offset(1f, 0f), dpadArm, color(XboxInput.DPAD_RIGHT))

        // Botões A B X Y (losango à direita)
        val faceCenter = Offset(w * 0.80f, h * 0.35f)
        val r = w * 0.05f
        drawCircle(color(XboxInput.Y), radius = r, center = faceCenter + Offset(0f, -r * 2.2f))
        drawCircle(color(XboxInput.A), radius = r, center = faceCenter + Offset(0f, r * 2.2f))
        drawCircle(color(XboxInput.X), radius = r, center = faceCenter + Offset(-r * 2.2f, 0f))
        drawCircle(color(XboxInput.B), radius = r, center = faceCenter + Offset(r * 2.2f, 0f))

        // Ombros LB/RB
        drawRoundRect(color(XboxInput.L1),
            topLeft = Offset(w * 0.10f, h * 0.06f), size = androidx.compose.ui.geometry.Size(w * 0.18f, h * 0.06f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f))
        drawRoundRect(color(XboxInput.R1),
            topLeft = Offset(w * 0.72f, h * 0.06f), size = androidx.compose.ui.geometry.Size(w * 0.18f, h * 0.06f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f))

        // Gatilhos LT/RT (representados como barras finas acima dos ombros)
        drawRoundRect(color(XboxInput.L2),
            topLeft = Offset(w * 0.10f, h * 0.0f), size = androidx.compose.ui.geometry.Size(w * 0.18f, h * 0.04f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f))
        drawRoundRect(color(XboxInput.R2),
            topLeft = Offset(w * 0.72f, h * 0.0f), size = androidx.compose.ui.geometry.Size(w * 0.18f, h * 0.04f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f))

        // Start / Back
        drawCircle(color(XboxInput.BACK), radius = w * 0.02f, center = Offset(w * 0.44f, h * 0.30f))
        drawCircle(color(XboxInput.START), radius = w * 0.02f, center = Offset(w * 0.56f, h * 0.30f))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDpadArrow(
    center: Offset, dir: Offset, arm: Float, color: Color
) {
    val target = Offset(center.x + dir.x * arm * 2.2f, center.y + dir.y * arm * 2.2f)
    drawLine(color, center, target, strokeWidth = arm, cap = androidx.compose.ui.graphics.StrokeCap.Round)
}

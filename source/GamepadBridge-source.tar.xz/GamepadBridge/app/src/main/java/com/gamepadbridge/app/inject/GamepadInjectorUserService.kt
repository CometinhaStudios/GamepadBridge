package com.gamepadbridge.app.inject

import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent

/**
 * Executado pelo Shizuku com UID "shell" (não root), num processo separado
 * do app. O shell tem a permissão de sistema INJECT_EVENTS, então aqui a
 * gente consegue chamar o método oculto InputManager#injectInputEvent via
 * reflexão — é exatamente o mecanismo que o `adb shell input` usa por baixo.
 *
 * Esse arquivo roda fora do processo normal do app: nada de Context/Activity
 * aqui, só reflexão sobre android.hardware.input.InputManager.
 */
class GamepadInjectorUserService : IGamepadInjector.Stub() {

    private val inputManager: Any by lazy {
        Class.forName("android.hardware.input.InputManager")
            .getMethod("getInstance")
            .invoke(null)
    }

    private val injectMethod by lazy {
        inputManager.javaClass.getMethod(
            "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
        )
    }

    // INPUT_EVENT_INJECTION_SYNC_NONE = 0 (não espera confirmação, mais rápido/fluido)
    private val INJECT_MODE_ASYNC = 0

    override fun injectKey(keyCode: Int, down: Boolean, source: Int) {
        val now = android.os.SystemClock.uptimeMillis()
        val action = if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
        val event = KeyEvent(now, now, action, keyCode, 0, 0, -1, 0, 0, source)
        runCatching { injectMethod.invoke(inputManager, event, INJECT_MODE_ASYNC) }
    }

    override fun injectAxisBatch(axes: IntArray, values: FloatArray, source: Int) {
        if (axes.isEmpty()) return
        val now = android.os.SystemClock.uptimeMillis()

        val props = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_UNKNOWN
        })
        val coords = arrayOf(MotionEvent.PointerCoords().apply {
            for (i in axes.indices) setAxisValue(axes[i], values[i])
        })

        val event = MotionEvent.obtain(
            now, now, MotionEvent.ACTION_MOVE, 1, props, coords,
            0, 0, 1f, 1f, 0, 0, source, 0
        )
        runCatching { injectMethod.invoke(inputManager, event, INJECT_MODE_ASYNC) }
        event.recycle()
    }

    override fun destroy() {
        // Shizuku chama isso quando o app se desconecta do UserService.
    }
}

package com.gamepadbridge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gamepadbridge.app.data.GameProfile
import com.gamepadbridge.app.data.ProfileStore
import com.gamepadbridge.app.inject.ShizukuBridge
import com.gamepadbridge.app.service.GamepadBridgeService
import com.gamepadbridge.app.ui.MappingScreen
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private var shizukuAvailable by mutableStateOf(false)
    private var shizukuPermission by mutableStateOf(false)

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        refreshShizukuState()
        if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) ShizukuBridge.bind(this)
    }

    private fun refreshShizukuState() {
        val available = ShizukuBridge.isAvailable
        shizukuAvailable = available
        shizukuPermission = available && ShizukuBridge.hasPermission
        if (shizukuPermission) ShizukuBridge.bind(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        refreshShizukuState()

        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                val profileStore = remember { ProfileStore(applicationContext) }
                val profiles by profileStore.profilesFlow.collectAsState(initial = emptyList())
                val activeProfileId by profileStore.activeProfileIdFlow.collectAsState(initial = null)
                val coroutineScope = rememberCoroutineScope()

                LaunchedEffect(profiles, activeProfileId) {
                    if (activeProfileId == null) profiles.firstOrNull()?.let { profileStore.selectProfile(it.id) }
                }

                NavHost(navController, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            profiles = profiles,
                            activeProfileId = activeProfileId,
                            shizukuAvailable = shizukuAvailable,
                            shizukuPermission = shizukuPermission,
                            onRefreshShizuku = ::refreshShizukuState,
                            onRequestShizukuPermission = { ShizukuBridge.requestPermission() },
                            onSelectProfile = { id -> coroutineScope.launch { profileStore.selectProfile(id) } },
                            onCreateProfile = { name -> coroutineScope.launch { profileStore.createProfile(name) } },
                            onDeleteProfile = { id -> coroutineScope.launch { profileStore.deleteProfile(id) } },
                            onMap = {
                                val selectedId = activeProfileId ?: profiles.firstOrNull()?.id
                                if (selectedId != null) navController.navigate("mapping/$selectedId")
                            },
                            onToggleService = { starting ->
                                if (starting) GamepadBridgeService.start(this@MainActivity)
                                else GamepadBridgeService.stop(this@MainActivity)
                            }
                        )
                    }
                    composable("mapping/{profileId}") { entry ->
                        val profileId = entry.arguments?.getString("profileId").orEmpty()
                        val profileName = profiles.firstOrNull { it.id == profileId }?.name ?: "Perfil"
                        MappingScreen(
                            profileId = profileId,
                            profileName = profileName,
                            profileStore = profileStore
                        ) { navController.popBackStack() }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshShizukuState()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}

@Composable
private fun HomeScreen(
    profiles: List<GameProfile>,
    activeProfileId: String?,
    shizukuAvailable: Boolean,
    shizukuPermission: Boolean,
    onRefreshShizuku: () -> Unit,
    onRequestShizukuPermission: () -> Unit,
    onSelectProfile: (String) -> Unit,
    onCreateProfile: (String) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onMap: () -> Unit,
    onToggleService: (Boolean) -> Unit
) {
    var serviceRunning by remember { mutableStateOf(false) }
    var profileMenuExpanded by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }
    val activeProfile = profiles.firstOrNull { it.id == activeProfileId } ?: profiles.firstOrNull()
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Gamepad Bridge", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Mapeie controles e teclados para entradas de gamepad. Cada jogo pode ter seu próprio perfil.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(24.dp))

        if (!shizukuAvailable) {
            Text("Serviço Shizuku indisponível. Abra o Shizuku, inicie o serviço e volte aqui.")
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onRefreshShizuku, modifier = Modifier.fillMaxWidth()) {
                Text("Verificar Shizuku novamente")
            }
        } else if (!shizukuPermission) {
            Text("Shizuku conectado. Falta autorizar o Gamepad Bridge.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = onRequestShizukuPermission, modifier = Modifier.fillMaxWidth()) {
                Text("Conceder acesso ao Shizuku")
            }
            TextButton(onClick = onRefreshShizuku) { Text("Verificar permissão") }
        } else {
            Text("Shizuku conectado e autorizado.", color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(20.dp))
            Text("Perfis por jogo", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { profileMenuExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = profiles.isNotEmpty()
                ) {
                    Text(activeProfile?.name ?: "Nenhum perfil criado")
                }
                DropdownMenu(
                    expanded = profileMenuExpanded,
                    onDismissRequest = { profileMenuExpanded = false }
                ) {
                    profiles.forEach { profile ->
                        DropdownMenuItem(
                            text = { Text(profile.name) },
                            onClick = {
                                profileMenuExpanded = false
                                if (serviceRunning) {
                                    serviceRunning = false
                                    onToggleService(false)
                                }
                                onSelectProfile(profile.id)
                            },
                            trailingIcon = {
                                if (profile.id == activeProfile?.id) Text("Ativo")
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { showCreateDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text("+ Criar perfil")
            }
            if (activeProfile != null) {
                Spacer(Modifier.height(14.dp))
                Text(
                    activeProfile.controller?.let { "Dispositivo: ${it.deviceLabel}" } ?: "Este perfil ainda não tem mapeamento.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (serviceRunning) {
                            serviceRunning = false
                            onToggleService(false)
                        }
                        onMap()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (activeProfile.controller == null) "Mapear controle / teclado" else "Editar mapeamento")
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        serviceRunning = !serviceRunning
                        onToggleService(serviceRunning)
                    },
                    enabled = activeProfile.controller?.mapping?.isNotEmpty() == true,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (serviceRunning) "Parar ponte" else "Iniciar ponte") }
                if (profiles.size > 1) {
                    TextButton(onClick = {
                        if (serviceRunning) {
                            serviceRunning = false
                            onToggleService(false)
                        }
                        onDeleteProfile(activeProfile.id)
                    }) { Text("Excluir perfil ativo") }
                }
            }
            TextButton(onClick = onRefreshShizuku) { Text("Atualizar conexão") }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Criar perfil") },
            text = {
                Column {
                    Text("Use um nome que identifique o jogo, por exemplo Minecraft ou GTA.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        label = { Text("Nome do perfil") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = newProfileName.trim()
                    if (name.isNotEmpty()) {
                        if (serviceRunning) {
                            serviceRunning = false
                            onToggleService(false)
                        }
                        onCreateProfile(name)
                    }
                    newProfileName = ""
                    showCreateDialog = false
                }, enabled = newProfileName.isNotBlank()) { Text("Criar") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancelar") }
            }
        )
    }
}

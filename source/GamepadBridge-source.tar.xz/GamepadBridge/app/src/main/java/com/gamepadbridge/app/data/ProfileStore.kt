package com.gamepadbridge.app.data

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.dataStore by preferencesDataStore(name = "gamepad_bridge_profile")
private val PROFILES_KEY = stringPreferencesKey("game_profiles_v2")
private val ACTIVE_PROFILE_KEY = stringPreferencesKey("active_game_profile")
private val LEGACY_PROFILE_KEY = stringPreferencesKey("profile")

data class GameProfile(
    val id: String,
    val name: String,
    val controller: ControllerProfile? = null
)

class ProfileStore(private val context: Context) {
    val profilesFlow: Flow<List<GameProfile>> = context.dataStore.data.map { prefs ->
        val encoded = prefs[PROFILES_KEY]
        if (!encoded.isNullOrBlank()) decodeProfiles(encoded)
        else {
            // Migrate the single-profile format used by the first beta.
            val legacy = prefs[LEGACY_PROFILE_KEY]?.let(ControllerProfile::deserialize)
            if (legacy == null) emptyList() else listOf(GameProfile("legacy-default", "Padrão", legacy))
        }
    }

    val activeProfileIdFlow: Flow<String?> = context.dataStore.data.map { it[ACTIVE_PROFILE_KEY] }

    val activeProfileFlow: Flow<GameProfile?> = context.dataStore.data.map { prefs ->
        val profiles = prefs[PROFILES_KEY]?.let(::decodeProfiles) ?: run {
            val legacy = prefs[LEGACY_PROFILE_KEY]?.let(ControllerProfile::deserialize)
            if (legacy == null) emptyList() else listOf(GameProfile("legacy-default", "Padrão", legacy))
        }
        val id = prefs[ACTIVE_PROFILE_KEY]
        profiles.firstOrNull { it.id == id } ?: profiles.firstOrNull()
    }

    suspend fun createProfile(name: String): GameProfile {
        val safeName = name.trim().ifBlank { "Novo perfil" }
        val profile = GameProfile(UUID.randomUUID().toString(), safeName)
        context.dataStore.edit { prefs ->
            val current = readProfiles(prefs[PROFILES_KEY], prefs[LEGACY_PROFILE_KEY])
            prefs[PROFILES_KEY] = encodeProfiles(current + profile)
            prefs[ACTIVE_PROFILE_KEY] = profile.id
            prefs.remove(LEGACY_PROFILE_KEY)
        }
        return profile
    }

    suspend fun renameProfile(id: String, name: String) {
        val safeName = name.trim()
        if (safeName.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = readProfiles(prefs[PROFILES_KEY], prefs[LEGACY_PROFILE_KEY])
            prefs[PROFILES_KEY] = encodeProfiles(current.map { if (it.id == id) it.copy(name = safeName) else it })
            prefs.remove(LEGACY_PROFILE_KEY)
        }
    }

    suspend fun deleteProfile(id: String) {
        context.dataStore.edit { prefs ->
            val current = readProfiles(prefs[PROFILES_KEY], prefs[LEGACY_PROFILE_KEY])
            val remaining = current.filterNot { it.id == id }
            prefs[PROFILES_KEY] = encodeProfiles(remaining)
            if (prefs[ACTIVE_PROFILE_KEY] == id) {
                val nextId = remaining.firstOrNull()?.id
                if (nextId == null) prefs.remove(ACTIVE_PROFILE_KEY) else prefs[ACTIVE_PROFILE_KEY] = nextId
            }
            prefs.remove(LEGACY_PROFILE_KEY)
        }
    }

    suspend fun selectProfile(id: String) {
        context.dataStore.edit { prefs ->
            val current = readProfiles(prefs[PROFILES_KEY], prefs[LEGACY_PROFILE_KEY])
            if (current.any { it.id == id }) prefs[ACTIVE_PROFILE_KEY] = id
        }
    }

    suspend fun saveControllerProfile(id: String, controller: ControllerProfile) {
        context.dataStore.edit { prefs ->
            val current = readProfiles(prefs[PROFILES_KEY], prefs[LEGACY_PROFILE_KEY])
            val updated = current.map { if (it.id == id) it.copy(controller = controller) else it }
            prefs[PROFILES_KEY] = encodeProfiles(updated)
            prefs[ACTIVE_PROFILE_KEY] = id
            prefs.remove(LEGACY_PROFILE_KEY)
        }
    }

    suspend fun activeControllerProfile(): ControllerProfile? = activeProfileFlow.first()?.controller

    private fun readProfiles(encoded: String?, legacyText: String?): List<GameProfile> {
        if (!encoded.isNullOrBlank()) return decodeProfiles(encoded)
        val legacy = legacyText?.let(ControllerProfile::deserialize)
        return if (legacy == null) emptyList() else listOf(GameProfile("legacy-default", "Padrão", legacy))
    }

    private fun encodeProfiles(profiles: List<GameProfile>): String {
        val array = JSONArray()
        profiles.forEach { profile ->
            val objectValue = JSONObject()
                .put("id", profile.id)
                .put("name", profile.name)
            profile.controller?.let { controller ->
                val mapping = JSONObject()
                controller.mapping.forEach { (input, source) -> mapping.put(input.name, source.serialize()) }
                objectValue.put("deviceNode", controller.deviceName)
                    .put("deviceLabel", controller.deviceLabel)
                    .put("mapping", mapping)
            }
            array.put(objectValue)
        }
        return Base64.encodeToString(array.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    private fun decodeProfiles(encoded: String): List<GameProfile> = runCatching {
        val text = String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8)
        val array = JSONArray(text)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val mappingObject = item.optJSONObject("mapping")
                val mapping = mutableMapOf<XboxInput, RawSource>()
                if (mappingObject != null) {
                    val keys = mappingObject.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        runCatching {
                            val input = XboxInput.valueOf(key)
                            val source = RawSource.deserialize(mappingObject.getString(key))
                            if (source != null) mapping[input] = source
                        }
                    }
                }
                val node = item.optString("deviceNode", "")
                val controller = if (node.isBlank()) null else ControllerProfile(
                    node,
                    mapping,
                    item.optString("deviceLabel", node)
                )
                add(GameProfile(item.optString("id", UUID.randomUUID().toString()), item.optString("name", "Perfil"), controller))
            }
        }
    }.getOrDefault(emptyList())
}

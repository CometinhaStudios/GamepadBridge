package com.gamepadbridge.app.input

import com.gamepadbridge.app.data.RawSource
import kotlinx.coroutines.flow.MutableSharedFlow
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.abs

object CalibrationCapture {
    val events = MutableSharedFlow<RawSource>(extraBufferCapacity = 32)

    private val generation = AtomicInteger(0)
    private val axisRestValue = HashMap<String, Int>()

    fun start(node: String) {
        val token = generation.incrementAndGet()
        synchronized(axisRestValue) { axisRestValue.clear() }
        thread(name = "calibration-capture") {
            DeviceNodeReader.streamEvents(
                node = node,
                onLine = { line ->
                    when (line.type) {
                        "EV_KEY" -> when (line.value.trim()) {
                            "DOWN" -> events.tryEmit(RawSource.Key(line.code))
                        }
                        "EV_ABS" -> {
                            val raw = parseRawValue(line.value) ?: return@streamEvents
                            val rest = synchronized(axisRestValue) {
                                axisRestValue.getOrPut(line.code) { raw }
                            }
                            if (abs(raw.toLong() - rest.toLong()) > 45L) {
                                events.tryEmit(RawSource.Axis(line.code, raw > rest))
                            }
                        }
                    }
                },
                shouldStop = { generation.get() != token }
            )
        }
    }

    fun stop(node: String? = null) {
        generation.incrementAndGet()
        if (node != null) DeviceNodeReader.stop(node)
    }

    private fun parseRawValue(value: String): Int? = runCatching {
        val cleaned = value.trim().removePrefix("0x")
        if (cleaned.isEmpty()) return null
        cleaned.toLong(16).toInt()
    }.getOrNull()
}

package com.gamepadbridge.app.input

import com.gamepadbridge.app.data.RawSource
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlin.concurrent.thread

/**
 * Usado pela tela de mapeamento: lê o node do controle via getevent (Shizuku)
 * e emite um RawSource a cada botão pressionado ou eixo movido de forma
 * clara (acima do limiar), pra tela consumir um de cada vez.
 */
object CalibrationCapture {
    val events = MutableSharedFlow<RawSource>(extraBufferCapacity = 16)

    @Volatile private var running = false
    private val axisRestValue = HashMap<String, Int>()

    fun start(node: String) {
        if (running) return
        running = true
        thread(name = "calibration-capture") {
            DeviceNodeReader.streamEvents(
                node = node,
                onLine = { line ->
                    when (line.type) {
                        "EV_KEY" -> if (line.value.trim() == "DOWN") {
                            events.tryEmit(RawSource.Key(line.code))
                        }
                        "EV_ABS" -> {
                            val raw = line.value.trim().toIntOrNull(16) ?: return@streamEvents
                            val rest = axisRestValue.getOrPut(line.code) { raw }
                            val delta = raw - rest
                            // limiar simples; eixos de 8 a 16 bits, então um delta
                            // grande o suficiente indica "o usuário mexeu de verdade"
                            if (kotlin.math.abs(delta) > 60) {
                                events.tryEmit(RawSource.Axis(line.code, delta > 0))
                            }
                        }
                    }
                },
                shouldStop = { !running }
            )
        }
    }

    fun stop() { running = false }
}

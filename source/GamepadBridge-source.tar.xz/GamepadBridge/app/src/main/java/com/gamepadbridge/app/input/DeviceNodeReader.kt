package com.gamepadbridge.app.input

import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

object DeviceNodeReader {
    data class RawLine(val type: String, val code: String, val value: String)
    data class DeviceEntry(
        val node: String,
        val name: String,
        val kind: String,
        val supportsKeyboard: Boolean,
        val supportsGamepad: Boolean
    )
    data class AxisRange(val min: Int, val max: Int) {
        fun normalize(raw: Int): Float {
            if (max <= min) return 0f
            return (((raw.coerceIn(min, max) - min).toFloat() / (max - min)) * 2f - 1f).coerceIn(-1f, 1f)
        }
        fun normalizeTrigger(raw: Int): Float {
            if (max <= min) return 0f
            return ((raw.coerceIn(min, max) - min).toFloat() / (max - min)).coerceIn(0f, 1f)
        }
    }

    private val activeProcesses = ConcurrentHashMap<String, Process>()

    /** Only show nodes that expose keyboard keys, gamepad buttons, or joystick axes. */
    fun listDevices(): List<DeviceEntry> {
        val output = runShell(arrayOf("getevent", "-il")) ?: return emptyList()
        val entries = mutableListOf<DeviceEntry>()
        var node: String? = null
        var name = "Dispositivo de entrada"
        val block = StringBuilder()

        fun flush() {
            val current = node ?: return
            val capabilities = block.toString()
            val keyboard = Regex("\\bKEY_(?:[A-Z]|[0-9]|F[0-9]{1,2}|KP[A-Z0-9_]*|ENTER|SPACE|TAB|ESC|BACKSPACE|UP|DOWN|LEFT|RIGHT|HOME|END|PAGEUP|PAGEDOWN|LEFTSHIFT|RIGHTSHIFT|LEFTCTRL|RIGHTCTRL|LEFTALT|RIGHTALT)\\b")
                .containsMatchIn(capabilities)
            val gamepad = Regex("\\bBTN_(?:[A-Z0-9_]+)\\b").containsMatchIn(capabilities) ||
                Regex("\\bABS_(?:X|Y|Z|RX|RY|RZ|HAT[0-9]+[XY]|BRAKE|GAS|THROTTLE|WHEEL|RUDDER)\\b").containsMatchIn(capabilities)
            val hasRawKeys = Regex("\\bKEY\\s*\\(").containsMatchIn(capabilities)
            val hasRawAxes = Regex("\\bABS\\s*\\(").containsMatchIn(capabilities)
            val lowerName = name.lowercase()
            val isTouchOrSensor = listOf("touchscreen", "touch screen", "touchpanel", "goodix", "ft5", "synaptics", "accelerometer", "gyroscope", "proximity", "light sensor").any { lowerName.contains(it) }
            val unknownInput = !isTouchOrSensor && (hasRawKeys || hasRawAxes)
            if (keyboard || gamepad || unknownInput) {
                val kind = when {
                    keyboard && gamepad -> "Controle / teclado"
                    gamepad -> "Controle"
                    keyboard -> "Teclado"
                    else -> "Entrada desconhecida (pode mapear)"
                }
                entries += DeviceEntry(current, name, kind, keyboard || hasRawKeys, gamepad || hasRawAxes)
            }
        }

        for (line in output.lineSequence()) {
            val match = Regex("""add device\s+\d+:\s+(/dev/input/event\d+)""").find(line)
            if (match != null) {
                flush()
                node = match.groupValues[1]
                name = "Dispositivo de entrada"
                block.setLength(0)
                continue
            }
            val nameMatch = Regex("""name:\s*"(.*)"""").find(line)
            if (nameMatch != null) name = nameMatch.groupValues[1]
            if (node != null) block.append(line).append('\n')
        }
        flush()
        return entries.distinctBy { it.node }
    }

    /** Parse the kernel-reported min/max values so 8-bit and 16-bit axes both work. */
    fun getAxisRanges(node: String): Map<String, AxisRange> {
        val output = runShell(arrayOf("getevent", "-lp", node)) ?: return emptyMap()
        val result = mutableMapOf<String, AxisRange>()
        val regex = Regex("""(ABS_[A-Z0-9_]+)\s*:\s*value\s+-?\d+,\s*min\s+(-?\d+),\s*max\s+(-?\d+)""")
        output.lineSequence().forEach { line ->
            val match = regex.find(line) ?: return@forEach
            val min = match.groupValues[2].toIntOrNull() ?: return@forEach
            val max = match.groupValues[3].toIntOrNull() ?: return@forEach
            if (max > min) result[match.groupValues[1]] = AxisRange(min, max)
        }
        return result
    }

    fun streamEvents(node: String, onLine: (RawLine) -> Unit, shouldStop: () -> Boolean) {
        val process = runShizukuCommand(arrayOf("getevent", "-l", node)) ?: return
        activeProcesses[node] = process
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        try {
            while (!shouldStop()) {
                val line = reader.readLine() ?: break
                val parsed = parseLine(line) ?: continue
                onLine(parsed)
            }
        } finally {
            activeProcesses.remove(node, process)
            runCatching { reader.close() }
            runCatching { process.destroy() }
        }
    }

    fun stop(node: String) {
        activeProcesses[node]?.let { process ->
            runCatching { process.destroy() }
        }
    }

    private fun parseLine(line: String): RawLine? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 3) return null
        val typeIndex = parts.indexOfLast { it.startsWith("EV_") }
        if (typeIndex < 0 || typeIndex + 2 >= parts.size) return null
        return RawLine(parts[typeIndex], parts[typeIndex + 1], parts[typeIndex + 2])
    }

    private fun runShell(command: Array<String>): String? = runCatching {
        val process = runShizukuCommand(command) ?: return null
        val text = process.inputStream.bufferedReader().use { it.readText() }
        process.waitFor(8, TimeUnit.SECONDS)
        process.destroy()
        text
    }.getOrNull()

    /** Shizuku's newProcess is exposed differently between API releases; use reflection. */
    private fun runShizukuCommand(command: Array<String>): Process? = runCatching {
        val method = Shizuku::class.java.declaredMethods.firstOrNull {
            it.name == "newProcess" && it.parameterTypes.size == 3
        } ?: return null
        method.isAccessible = true
        method.invoke(null, command, null, null) as? Process
    }.getOrNull()
}

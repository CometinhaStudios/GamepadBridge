package com.gamepadbridge.app.input

import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Lê o controle físico direto do kernel via `getevent`, rodando como shell
 * (Shizuku) — funciona mesmo com o jogo em primeiro plano, porque não
 * depende da janela do nosso app ter foco.
 *
 * ATENÇÃO: os nomes exatos (ex: /dev/input/eventX) e os códigos EV_KEY/EV_ABS
 * variam de controle pra controle. Isso aqui cobre o caso comum; pode
 * precisar de ajuste fino rodando `adb shell getevent -lp` com o controle
 * conectado e comparando a saída real.
 */
object DeviceNodeReader {

    data class RawLine(val type: String, val code: String, val value: String)

    data class DeviceEntry(val node: String, val name: String)

    /** Lista todos os dispositivos de entrada visíveis, pra o usuário escolher qual é o controle. */
    fun listDevices(): List<DeviceEntry> {
        val output = runShell("getevent -il") ?: return emptyList()
        val result = mutableListOf<DeviceEntry>()
        var currentNode: String? = null
        for (line in output.lines()) {
            val nodeMatch = Regex("""add device \d+: (/dev/input/event\d+)""").find(line)
            if (nodeMatch != null) currentNode = nodeMatch.groupValues[1]
            val nameMatch = Regex("""name:\s*"(.*)"""").find(line)
            if (nameMatch != null && currentNode != null) {
                result.add(DeviceEntry(currentNode, nameMatch.groupValues[1]))
            }
        }
        return result
    }

    /** Começa a ler eventos em loop; chama [onLine] pra cada linha, até [shouldStop] virar true. */
    fun streamEvents(node: String, onLine: (RawLine) -> Unit, shouldStop: () -> Boolean) {
        val process = Shizuku.newProcess(arrayOf("getevent", "-l", node), null, null)
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        try {
            var line: String?
            while (!shouldStop() && reader.readLine().also { line = it } != null) {
                val parsed = parseLine(line!!) ?: continue
                onLine(parsed)
            }
        } finally {
            runCatching { process.destroy() }
        }
    }

    // Formato típico: "/dev/input/event5: EV_KEY       BTN_SOUTH           DOWN"
    //              ou: "/dev/input/event5: EV_ABS       ABS_X               000000ff"
    private fun parseLine(line: String): RawLine? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 3) return null
        val type = parts[parts.size - 3]
        val code = parts[parts.size - 2]
        val value = parts[parts.size - 1]
        if (!type.startsWith("EV_")) return null
        return RawLine(type, code, value)
    }

    private fun runShell(cmd: String): String? {
        return runCatching {
            val process = Shizuku.newProcess(cmd.split(" ").toTypedArray(), null, null)
            process.inputStream.bufferedReader().readText()
        }.getOrNull()
    }
}
